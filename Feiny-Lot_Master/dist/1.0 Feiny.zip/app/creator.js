let certificateLookupCache = {
  labs: [],
  descriptors: [],
  supplements: []
};

let certificateFiles = new Map();
let certificateFilesToUpload = [];
let diaImageFile = null;
let stoneImageFile = null;
let speciesMap = {};
let isApplying = false;

document.addEventListener("DOMContentLoaded", function () {

  /* ================= SECTION VISIBILITY ================= */

  function getElements() {
    return {
      itemTypeEl           : document.getElementById("itemType"),
      colorStoneSection    : document.getElementById("colorStoneSection"),
      diamondSection       : document.getElementById("diamondSection"),
      jewelleryWrapper     : document.getElementById("jewelleryWrapper"),
      pricingSection       : document.getElementById("pricingSection"),
      Dimensionssection    : document.getElementById("Dimensionssection"),
      neededcertificatesec : document.getElementById("neededcertificatesec"),
      certificateuploadsec : document.getElementById("certificateuploadsec"),
      partnershipsec       : document.getElementById("partnershipsec"),
    };
  }

  function hide(el) {
    if (el) el.style.setProperty("display", "none", "important");
  }

  function show(el) {
    if (el) el.style.setProperty("display", "block", "important");
  }

  function applyVisibility() {
    let isApplying = false;
    isApplying = true;

    const {
      itemTypeEl, colorStoneSection, diamondSection,
      jewelleryWrapper, pricingSection, Dimensionssection,
      neededcertificatesec, certificateuploadsec, partnershipsec
    } = getElements();

    hide(colorStoneSection);
    hide(diamondSection);
    hide(jewelleryWrapper);
    hide(pricingSection);
    hide(Dimensionssection);
    hide(neededcertificatesec);
    hide(certificateuploadsec);
    hide(partnershipsec);

    if (!itemTypeEl) { isApplying = false; return; }

    const selectedValue = itemTypeEl.value.trim();
    console.log("selectedValue:", selectedValue);

    if (selectedValue === "Color Stone") {
      show(colorStoneSection);
      show(pricingSection);
      show(Dimensionssection);
      show(neededcertificatesec);
      show(certificateuploadsec);
      show(partnershipsec);
    }
    else if (selectedValue === "Diamond") {
      show(diamondSection);
      show(certificateuploadsec);
      show(neededcertificatesec);
      show(partnershipsec);
    }
    else if (selectedValue === "Jewellery") {
      show(jewelleryWrapper);
    }

    setTimeout(() => { isApplying = false; }, 50);
  }

  setTimeout(applyVisibility, 300);

  document.addEventListener("change", function (e) {
    if (e.target && e.target.id === "itemType") {
      setTimeout(applyVisibility, 100);
    }
  });

  const observer = new MutationObserver(function () {
    if (document.getElementById("itemType")) {
        setTimeout(applyVisibility, 100);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  /* ================= LOOKUP LOADS ================= */

  typeof loadUnitLookup === "function" && loadUnitLookup();
  typeof loadTreatmentLookup === "function" && loadTreatmentLookup();
  typeof loadShapeLookup === "function" && loadShapeLookup();
  typeof loadSpeciesLookup === "function" && loadSpeciesLookup();
  typeof loadSurfaceLookup === "function" && loadSurfaceLookup();
  typeof loadCountryDropdown === "function" && loadCountryDropdown();
  typeof loadCountrycutDropdown === "function" && loadCountrycutDropdown();
  typeof loadDiaColorLookup === "function" && loadDiaColorLookup();
  typeof loadDiaClarityLookup === "function" && loadDiaClarityLookup();
  typeof loadDiaCutLookup === "function" && loadDiaCutLookup();
  typeof loadDiaPolishLookup === "function" && loadDiaPolishLookup();
  typeof loadDiaSymmetryLookup === "function" && loadDiaSymmetryLookup();
  typeof loadDiaCuletLookup === "function" && loadDiaCuletLookup();
  typeof loadDiaFluorescenceLookup === "function" && loadDiaFluorescenceLookup();
  typeof loadDiaFluorescenceColorLookup === "function" && loadDiaFluorescenceColorLookup();
  typeof loaddiaShapeLookup === "function" && loaddiaShapeLookup();
  typeof loadPartnerLookup === "function" && loadPartnerLookup();
  typeof loadPartnerdataLookup === "function" && loadPartnerdataLookup();
  typeof initTotalCalculation === "function" && initTotalCalculation();
  typeof initRapportPriceTriggers === "function" && initRapportPriceTriggers();

  typeof loadCertificateSubformLookups === "function" && loadCertificateSubformLookups();

  /* ================= Color Stone AUTO DESCRIPTION ================= */

  const treatmentEl = document.getElementById("treatment_lookup");
  const speciesEl   = document.getElementById("species_lookup");
  const surfaceEl   = document.getElementById("surface_lookup");
  const shapeEl     = document.getElementById("shape_lookup");

  const shortDescEl = document.getElementById("cs_short_description");
  const longDescEl  = document.getElementById("cs_long_description");

  function stoneupdateDescriptions() {
    const treatment = treatmentEl?.selectedOptions[0]?.text || "";
    const species   = speciesEl?.selectedOptions[0]?.text || "";
    const surface   = surfaceEl?.selectedOptions[0]?.text || "";
    const shape     = shapeEl?.selectedOptions[0]?.text || "";

    const shortText = [treatment, species, surface, shape].filter(Boolean).join(" ");
    const longText  = [treatment, species, surface, shape].filter(Boolean).join(", ");

    if (shortDescEl) shortDescEl.value = shortText;
    if (longDescEl)  longDescEl.value  = longText;
  }

  [treatmentEl, speciesEl, surfaceEl, shapeEl].forEach(el => {
    if (el) el.addEventListener("change", stoneupdateDescriptions);
  });

  stoneupdateDescriptions();

  /* ================= AUTO TOTAL PRICE (ZOHO FIX) ================= */

  function initTotalCalculation() {
    const weightField = document.getElementById("dia_weight");
    const priceField  = document.getElementById("price_per_carat");
    const totalField  = document.getElementById("total_price");

    if (!weightField || !priceField || !totalField) {
      setTimeout(initTotalCalculation, 500);
      return;
    }

    function calculateTotal() {
      const weight = parseFloat(weightField.value) || 0;
      const price  = parseFloat(priceField.value)  || 0;
      const total  = weight * price;
      totalField.value = total ? total.toFixed(2) : "";
    }

    weightField.addEventListener("input", calculateTotal);
    priceField.addEventListener("input", calculateTotal);
  }

  initTotalCalculation();

  /* ================= Diamond AUTO DESCRIPTION ================= */

  const diashapeEl               = document.getElementById("dia_shape");
  const diacolorEl               = document.getElementById("dia_color");
  const diaclarityEl             = document.getElementById("dia_clarity");
  const diacutEl                 = document.getElementById("dia_cut");
  const diapolishEl              = document.getElementById("dia_polish");
  const diasymmetryEl            = document.getElementById("dia_symmetry");
  const diaculetEl               = document.getElementById("dia_culet");
  const diafluorescenceEl        = document.getElementById("dia_fluorescence");
  const diafluorescencecolorEl   = document.getElementById("dia_colour_fluorescence");

  const diashortDescEl = document.getElementById("diashort_description");
  const dialongDescEl  = document.getElementById("dialong_description");

  function updateDescriptions() {
    const diashape             = diashapeEl?.selectedOptions[0]?.text             || "";
    const diacolor             = diacolorEl?.selectedOptions[0]?.text             || "";
    const diaclarity           = diaclarityEl?.selectedOptions[0]?.text           || "";
    const diacut               = diacutEl?.selectedOptions[0]?.text               || "";
    const diapolish            = diapolishEl?.selectedOptions[0]?.text            || "";
    const diasymmetry          = diasymmetryEl?.selectedOptions[0]?.text          || "";
    const diaculet             = diaculetEl?.selectedOptions[0]?.text             || "";
    const diafluorescence      = diafluorescenceEl?.selectedOptions[0]?.text      || "";
    const diafluorescencecolor = diafluorescencecolorEl?.selectedOptions[0]?.text || "";

    const shortText = [diashape, diacolor, diaclarity, diacut, diapolish, diasymmetry, diaculet, diafluorescence, diafluorescencecolor]
      .filter(Boolean).join(" ");
    const longText  = [diashape, diacolor, diaclarity, diacut, diapolish, diasymmetry, diaculet, diafluorescence, diafluorescencecolor]
      .filter(Boolean).join(", ");

    if (diashortDescEl) diashortDescEl.value = shortText;
    if (dialongDescEl)  dialongDescEl.value  = longText;
  }

  [diashapeEl, diacolorEl, diaclarityEl, shapeEl, diacutEl, diapolishEl, diasymmetryEl, diaculetEl, diafluorescenceEl, diafluorescencecolorEl].forEach(el => {
    if (el) el.addEventListener("change", updateDescriptions);
  });

  updateDescriptions();

  /* ================= DIAMOND IMAGE UPLOAD ================= */

const diaInput = document.getElementById("dia_image");
const preview  = document.getElementById("imagePreview");
const clearBtn = document.getElementById("clearImage");

if (diaInput && preview && clearBtn) {

  diaInput.addEventListener("change", function (e) {

    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("File must be under 5MB");
      diaInput.value = "";
      return;
    }

    diaImageFile = file;

    const reader = new FileReader();
    reader.onload = function (ev) {
      preview.src = ev.target.result;
      preview.style.display = "block";
      clearBtn.style.display = "inline-block";
    };
    reader.readAsDataURL(file);
  });

  clearBtn.addEventListener("click", function () {
    diaImageFile = null;
    diaInput.value = "";
    preview.style.display = "none";
    clearBtn.style.display = "none";
  });
}
  /* ================= STONE IMAGE UPLOAD ================= */
  const stoneInput    = document.getElementById("stone_image");
  const stonePreview  = document.getElementById("stoneImagePreview");
  const stoneClearBtn = document.getElementById("clearStoneImage");

  if (stoneInput) {
    stoneInput.addEventListener("change", function (e) {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) {
        alert("File must be under 5MB");
        stoneInput.value = "";
        return;
      }
      stoneImageFile = file;
      const reader = new FileReader();
      reader.onload = function (ev) {
        stonePreview.src = ev.target.result;
        stonePreview.style.display = "block";
        stoneClearBtn.style.display = "inline-block";
        document.getElementById("imageText").style.display = "none";
      };
      reader.readAsDataURL(file);
    });
  }

  if (stoneClearBtn) {
    stoneClearBtn.addEventListener("click", function () {
      stoneImageFile = null;
      stoneInput.value = "";
      stonePreview.style.display = "none";
      stoneClearBtn.style.display = "none";
      document.getElementById("imageText").style.display = "block";
    });
  }

});


/* ================= DIAMOND AUTO DESCRIPTION ================= */

const diaShapeEl        = document.getElementById("dia_shape");
const diaColorEl        = document.getElementById("dia_color");
const diaClarityEl      = document.getElementById("dia_clarity");
const diaCutEl          = document.getElementById("dia_cut");
const diaPolishEl       = document.getElementById("dia_polish");
const diaSymmetryEl     = document.getElementById("dia_symmetry");
const diaCuletEl        = document.getElementById("dia_culet");
const diaFluorescenceEl = document.getElementById("dia_fluorescence");

const shortDescEl = document.getElementById("short_description");
const longDescEl  = document.getElementById("long_description");

function updateDiamondDescriptions() {
  const shape        = diaShapeEl?.selectedOptions[0]?.text        || "";
  const color        = diaColorEl?.selectedOptions[0]?.text        || "";
  const clarity      = diaClarityEl?.selectedOptions[0]?.text      || "";
  const cut          = diaCutEl?.selectedOptions[0]?.text          || "";
  const polish       = diaPolishEl?.selectedOptions[0]?.text       || "";
  const symmetry     = diaSymmetryEl?.selectedOptions[0]?.text     || "";
  const culet        = diaCuletEl?.selectedOptions[0]?.text        || "";
  const fluorescence = diaFluorescenceEl?.selectedOptions[0]?.text || "";

  const shortText = [color, clarity, cut, shape, polish, symmetry, culet, fluorescence].filter(Boolean).join(" ");
  const longText  = [color, clarity, cut, shape, polish, symmetry, culet, fluorescence].filter(Boolean).join(", ");

  if (shortDescEl) shortDescEl.value = shortText;
  if (longDescEl)  longDescEl.value  = longText;
}

[diaShapeEl, diaColorEl, diaClarityEl, diaCutEl, diaPolishEl, diaSymmetryEl, diaCuletEl, diaFluorescenceEl].forEach(el => {
  if (el) el.addEventListener("change", updateDiamondDescriptions);
});

updateDiamondDescriptions();


/* =================================================================================
   CERTIFICATE SUBFORM LOOKUPS  ✅ FIXED
   — Replaced undefined getLookupData() with direct ZOHO.CREATOR.DATA.getRecords()
   — Fixed populateRowSelects() to use specific classes instead of dropdown_cls
   — Fixed addCertificateRow() to call populateRowSelects() after appending the row
   — Fixed fillSelect() to correctly resolve the display text per report
================================================================================= */

/* 🔹 LOAD ALL LOOKUPS (ONLY ONCE) */
function loadCertificateSubformLookups() {
  return Promise.all([
    ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "All_Labs" }),
    ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Lab_Descriptor_Report" }),
    ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "All_Laboratory_Supplements" })
  ])
  .then(function ([labsRes, descriptorsRes, supplementsRes]) {

    // ✅ Store parsed arrays in cache
    certificateLookupCache.labs        = labsRes.data        || [];
    certificateLookupCache.descriptors = descriptorsRes.data || [];
    certificateLookupCache.supplements = supplementsRes.data || [];

    console.log("Certificate Lookups Loaded:",
      certificateLookupCache.labs.length,        "labs |",
      certificateLookupCache.descriptors.length, "descriptors |",
      certificateLookupCache.supplements.length, "supplements"
    );

    // ✅ Populate any existing rows in the table
    const tableBody = document.getElementById("certificateBody");
    if (!tableBody) return;

    Array.from(tableBody.rows).forEach(function (row) {
      populateRowSelects(row);
    });
  })
  .catch(function (err) {
    console.error("Certificate subform lookup error:", err);
  });
}

/* 🔹 POPULATE SELECTS IN A GIVEN ROW (uses specific classes, not dropdown_cls) */
function populateRowSelects(row) {
  const labSelect     = row.querySelector(".cert-lab");
  const labDescSelect = row.querySelector(".cert-lab-desc");
  const labSupSelect  = row.querySelector(".cert-lab-sup");

  if (labSelect     && labSelect.options.length     <= 1) fillSelect(labSelect,     certificateLookupCache.labs,        "Lab");
  if (labDescSelect && labDescSelect.options.length <= 1) fillSelect(labDescSelect, certificateLookupCache.descriptors, "Lab_Descriptor");
  if (labSupSelect  && labSupSelect.options.length  <= 1) fillSelect(labSupSelect,  certificateLookupCache.supplements, "Laboratory_Supplement");
}

/* 🔹 FILL A SINGLE SELECT — fieldName tells which property to use as label */
function fillSelect(select, data, fieldName) {
  // ⚠️ Skip if already populated
  if (select.options.length > 1) return;

  select.innerHTML = `<option value="">Select</option>`;

  data.forEach(function (rec) {
    const opt   = document.createElement("option");
    opt.value   = rec.ID;
    opt.text    = rec[fieldName] || "";   // e.g. rec["Lab"], rec["Lab_Descriptor"], rec["Laboratory_Supplement"]
    select.appendChild(opt);
  });
}

/* 🔹 ADD NEW CERTIFICATE ROW */
function addCertificateRow() {
  const tbody = document.getElementById("certificateBody");
  if (!tbody) return;

  const tr = document.createElement("tr");
  tr.classList.add("cert-row");

  tr.innerHTML = `
    <td><button type="button" onclick="removeRow(this)">❌</button></td>
    <td><input class="cert-id"></td>
    <td><input type="file" class="cert-file"></td>
    <td><input type="date" class="cert-date"></td>
    <td><textarea class="cert-notes"></textarea></td>
    <td><select class="cert-lab"></select></td>
    <td><select class="cert-lab-desc"></select></td>
    <td><select class="cert-lab-sup"></select></td>
  `;

  tbody.appendChild(tr);

  // ✅ Populate the new row from the already-loaded cache
  populateRowSelects(tr);
}

/* 🔹 REMOVE ROW */
function removeRow(btn) {
  btn.closest("tr").remove();
}


/* ================= COUNTRY DROPDOWNS ================= */
function loadCountryDropdown() {
  const countries = [
    "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia",
    "Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Belgium",
    "Bhutan","Bolivia","Brazil","Bulgaria","Cambodia","Cameroon","Canada","Chile",
    "China","Colombia","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic",
    "Denmark","Dominican Republic","Ecuador","Egypt","Estonia","Ethiopia","Finland",
    "France","Georgia","Germany","Ghana","Greece","Greenland","Hungary","Iceland",
    "India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan",
    "Jordan","Kazakhstan","Kenya","Kuwait","Laos","Latvia","Lebanon","Lithuania",
    "Luxembourg","Malaysia","Maldives","Mexico","Mongolia","Morocco","Myanmar",
    "Nepal","Netherlands","New Zealand","Nigeria","North Korea","Norway","Oman",
    "Pakistan","Philippines","Poland","Portugal","Qatar","Romania","Russia",
    "Saudi Arabia","Singapore","South Africa","South Korea","Spain","Sri Lanka",
    "Sweden","Switzerland","Thailand","Turkey","Ukraine","United Arab Emirates",
    "United Kingdom","United States","Uruguay","Uzbekistan","Vietnam","Yemen",
    "Zambia","Zimbabwe"
  ];
  const select = document.getElementById("origin_country");
  if (!select) return;
  select.innerHTML = `<option value="">Select Country</option>`;
  countries.forEach(country => {
    const option = document.createElement("option");
    option.value = country;
    option.text  = country;
    select.appendChild(option);
  });
}

function loadCountrycutDropdown() {
  const countries = [
    "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia",
    "Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Belgium",
    "Bhutan","Bolivia","Brazil","Bulgaria","Cambodia","Cameroon","Canada","Chile",
    "China","Colombia","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic",
    "Denmark","Dominican Republic","Ecuador","Egypt","Estonia","Ethiopia","Finland",
    "France","Georgia","Germany","Ghana","Greece","Greenland","Hungary","Iceland",
    "India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan",
    "Jordan","Kazakhstan","Kenya","Kuwait","Laos","Latvia","Lebanon","Lithuania",
    "Luxembourg","Malaysia","Maldives","Mexico","Mongolia","Morocco","Myanmar",
    "Nepal","Netherlands","New Zealand","Nigeria","North Korea","Norway","Oman",
    "Pakistan","Philippines","Poland","Portugal","Qatar","Romania","Russia",
    "Saudi Arabia","Singapore","South Africa","South Korea","Spain","Sri Lanka",
    "Sweden","Switzerland","Thailand","Turkey","Ukraine","United Arab Emirates",
    "United Kingdom","United States","Uruguay","Uzbekistan","Vietnam","Yemen",
    "Zambia","Zimbabwe"
  ];
  const select = document.getElementById("country_cut");
  if (!select) return;
  select.innerHTML = `<option value="">Select Country</option>`;
  countries.forEach(country => {
    const option = document.createElement("option");
    option.value = country;
    option.text  = country;
    select.appendChild(option);
  });
}

/* ================= GLOBAL ================= */
let partnerList = [];


/* ================= LOAD PARTNER DATA ================= */
function loadPartnerLookup() {
  console.log("Loading Partner Lookup...");

  ZOHO.CREATOR.DATA.getRecords({
    app_name: "feiny-app",
    report_name: "All_Customers1"
  })
  .then(function (response) {

    console.log("Partner Response:", response);

    if (!response.data || response.data.length === 0) {
      console.warn("No Partner records found");
      return;
    }

    partnerList = response.data;
    populatePartnerDropdowns();

  })
  .catch(function (error) {
    console.error("Partner lookup error:", error);
    alert("Unable to load Partner lookup");
  });
}


/* ================= POPULATE DROPDOWNS ================= */
function populatePartnerDropdowns() {

  const dropdowns = document.querySelectorAll(".partner_lookup");

  dropdowns.forEach(function (dropdown) {

    const selectedValue = dropdown.value;

    dropdown.innerHTML = `<option value="">Select Partner</option>`;

    partnerList.forEach(function (record) {
      const option = document.createElement("option");

      option.value = record.ID;
      option.text  = record.Legal_Name || "No Name";

      if (selectedValue == record.ID) {
        option.selected = true;
      }

      dropdown.appendChild(option);
    });

  });
}


/* ================= ADD ROW ================= */
function addPartnerRow() {

  const tbody = document.getElementById("subform-body");
  if (!tbody) return;

  const newRow = document.createElement("tr");

  newRow.innerHTML = `
    <td>
      <select class="partner_lookup">
        <option value="">Select Partner</option>
      </select>
    </td>
    <td><input type="text"></td>
    <td><input type="text"></td>
    <td><input type="text"></td>
    <td style="text-align:center;"><input type="checkbox"></td>
    <td><textarea></textarea></td>
  `;

  tbody.appendChild(newRow);

  populatePartnerDropdowns();
}


/* ================= BUTTON CLICK ================= */
document.getElementById("addRowBtn").addEventListener("click", addPartnerRow);


/* ================= PAGE LOAD ================= */
document.addEventListener("DOMContentLoaded", function () {
  loadPartnerLookup(); // ✅ ONLY THIS
});

// ---------------Partner_Data_Lookup---------------

/* ================= GLOBAL ================= */
let partnerdataList = [];


/* ================= LOAD PARTNER DATA ================= */
function loadPartnerLookup() {
  console.log("Loading Partner Lookup...");

  ZOHO.CREATOR.DATA.getRecords({
    app_name: "feiny-app",
    report_name: "All_Customers1"
  })
  .then(function (response) {

    console.log("Partner Response:", response);

    if (!response.data || response.data.length === 0) {
      console.warn("No Partner records found");
      return;
    }

    partnerList = response.data;
    populatePartnerDropdowns();

  })
  .catch(function (error) {
    console.error("Partner lookup error:", error);
    alert("Unable to load Partner lookup");
  });
}


/* ================= POPULATE DROPDOWNS ================= */
function populatePartnerDropdowns() {

  const dropdowns = document.querySelectorAll(".partner_data_lookup");

  dropdowns.forEach(function (dropdown) {

    const selectedValue = dropdown.value;

    dropdown.innerHTML = `<option value="">Select Partner</option>`;

    partnerList.forEach(function (record) {
      const option = document.createElement("option");

      option.value = record.ID;
      option.text  = record.Legal_Name || "No Name";

      if (selectedValue == record.ID) {
        option.selected = true;
      }

      dropdown.appendChild(option);
    });

  });
}


/* ================= ADD ROW ================= */
function addPartnerRow() {

  const tbody = document.getElementById("subform-body");
  if (!tbody) return;

  const newRow = document.createElement("tr");

  newRow.innerHTML = `
    <td>
      <select class="partner_data_lookup">
        <option value="">Select Partner</option>
      </select>
    </td>
    <td><input type="text"></td>
    <td><input type="text"></td>
    <td><input type="text"></td>
    <td style="text-align:center;"><input type="checkbox"></td>
    <td><textarea></textarea></td>
  `;

  tbody.appendChild(newRow);

  populatePartnerDropdowns();
}


/* ================= BUTTON CLICK ================= */
document.getElementById("addRowBtn").addEventListener("click", addPartnerRow);


/* ================= PAGE LOAD ================= */
document.addEventListener("DOMContentLoaded", function () {
  loadPartnerLookup(); // ✅ ONLY THIS
});

/* ================= UNIT LOOKUP ================= */
function loadUnitLookup() {
  console.log("fuction call");
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Unit" })
  .then(function (response) {
    console.log("Unit records:", response);
    const unitSelect = document.getElementById("unit_lookup");
    if (!unitSelect) { console.error("unit_lookup select not found"); return; }
    unitSelect.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Unit records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      unitSelect.appendChild(option);
    });
  })
  .catch(function (error) {
    console.error("Unit lookup error:", error);
    alert("Unable to load Unit lookup");
  });
}


/* ================= SURFACE LOOKUP ================= */
function loadSurfaceLookup() {
  console.log("fuction call--1");
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "All_Surface" })
  .then(function (response) {
    console.log("Surface records:", response);
    const unitSelect = document.getElementById("surface_lookup");
    if (!unitSelect) { console.error("surface_lookup select not found"); return; }
    unitSelect.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No surface records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      unitSelect.appendChild(option);
    });
  })
  .catch(function (error) {
    console.error("Sureface lookup error:", error);
    alert("Unable to load Sureface lookup");
  });
}

/* ================= TREATMENT LOOKUP ================= */
function loadTreatmentLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Treatment" })
  .then(function (response) {
    const select = document.getElementById("treatment_lookup");
    if (!select) { console.error("treatment_lookup select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Treatment records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Treatment lookup error:", error); });
}

/* ================= SHAPE LOOKUP ================= */
function loadShapeLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Shape" })
  .then(function (response) {
    const select = document.getElementById("shape_lookup");
    if (!select) { console.error("shape_lookup select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Shape records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Shape lookup error:", error); });
}

/* ================= DIA SHAPE LOOKUP ================= */
function loaddiaShapeLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Shape" })
  .then(function (response) {
    const select = document.getElementById("dia_shape");
    if (!select) { console.error("shape_lookup select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Shape records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Shape lookup error:", error); });
}

/* ================= DIAMOND COLOR LOOKUP ================= */
function loadDiaColorLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Color" })
  .then(function (response) {
    const select = document.getElementById("dia_color");
    if (!select) { console.error("dia_color select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Colour records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Colour lookup error:", error); });
}

/* ================= DIAMOND CLARITY LOOKUP ================= */
function loadDiaClarityLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Clarity" })
  .then(function (response) {
    const select = document.getElementById("dia_clarity");
    if (!select) { console.error("dia_Clarity select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Clarity records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Clarity lookup error:", error); });
}

/* ================= DIAMOND CUT LOOKUP ================= */
function loadDiaCutLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Cut" })
  .then(function (response) {
    const select = document.getElementById("dia_cut");
    if (!select) { console.error("dia_cut select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No cut records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Clarity lookup error:", error); });
}

/* ================= DIAMOND POLISH LOOKUP ================= */
function loadDiaPolishLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Polish" })
  .then(function (response) {
    const select = document.getElementById("dia_polish");
    if (!select) { console.error("dia_polish select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Polish records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Polish lookup error:", error); });
}

/* ================= DIAMOND SYMMETRY LOOKUP ================= */
function loadDiaSymmetryLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Polish" })
  .then(function (response) {
    const select = document.getElementById("dia_symmetry");
    if (!select) { console.error("dia_symmetry select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No symmetry records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("Symmetry lookup error:", error); });
}

/* ================= DIAMOND CULET LOOKUP ================= */
function loadDiaCuletLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Cutlet" })
  .then(function (response) {
    const select = document.getElementById("dia_culet");
    if (!select) { console.error("dia_culet select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No culet records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("culet lookup error:", error); });
}

/* ================= DIAMOND FLUORESCENCE LOOKUP ================= */
function loadDiaFluorescenceLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Fluroscence" })
  .then(function (response) {
    const select = document.getElementById("dia_fluorescence");
    if (!select) { console.error("dia_fluorescence select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No fluorescence records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("fluorescence lookup error:", error); });
}

/* ================= DIAMOND FLUORESCENCE COLOR LOOKUP ================= */
function loadDiaFluorescenceColorLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "Fluroscence_color" })
  .then(function (response) {
    const select = document.getElementById("dia_colour_fluorescence");
    if (!select) { console.error("dia_colour_fluorescence select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No Colour_fluorescence records found"); return; }
    response.data.forEach(function (record) {
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Description1;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("colour_fluorescence lookup error:", error); });
}

/* ================= SPECIES LOOKUP ================= */
function loadSpeciesLookup() {
  ZOHO.CREATOR.DATA.getRecords({ app_name: "feiny-app", report_name: "All_Stone_Species" })
  .then(function (response) {
    const select = document.getElementById("species_lookup");
    if (!select) { console.error("species_lookup select not found"); return; }
    select.innerHTML = `<option value="">None</option>`;
    if (!response.data || response.data.length === 0) { console.warn("No species records found"); return; }
    response.data.forEach(function (record) {
      speciesMap[record.ID] = record;
      const option = document.createElement("option");
      option.value = record.ID;
      option.text  = record.Species;
      select.appendChild(option);
    });
  })
  .catch(function (error) { console.error("species lookup error:", error); });
}

/* ================= RAPPORT PRICE ================= */
function initRapportPriceTriggers() {
  const fields = ["dia_shape", "dia_color", "dia_clarity", "dia_weight"];
  fields.forEach(function(id) {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener("change", fetchRapportPrice);
      el.addEventListener("input",  fetchRapportPrice);
    }
  });
}

function fetchRapportPrice() {
  const shapeEl   = document.getElementById("dia_shape");
  const colorEl   = document.getElementById("dia_color");
  const clarityEl = document.getElementById("dia_clarity");
  const weightEl  = document.getElementById("dia_weight");

  const shape   = shapeEl?.selectedOptions[0]?.text?.trim();
  const color   = colorEl?.selectedOptions[0]?.text?.trim();
  const clarity = clarityEl?.selectedOptions[0]?.text?.trim();
  const weight  = parseFloat(weightEl?.value);

  if (!shape   || shape   === "None" || shape   === "Select" ||
      !color   || color   === "None" || color   === "Select" ||
      !clarity || clarity === "None" || clarity === "Select" ||
      isNaN(weight) || weight <= 0) {
    document.getElementById("rapport_price").value = "";
    return;
  }

  const colorLC   = color.toLowerCase();
  const clarityLC = clarity.toLowerCase();

  console.log("Fetching Rapport Price for:", shape, colorLC, clarityLC, weight);

  const criteria = `(shape == "${shape}" && Color == "${colorLC}" && Clarity == "${clarityLC}" && Weight_high_size1 >= ${weight})`;
  console.log("Criteria:", criteria);

  ZOHO.CREATOR.DATA.getRecords({
    app_name: "feiny-app",
    report_name: "All_Rapaport_Masters",
    criteria: criteria,
    max_records: 200
  })
  .then(function(response) {
    console.log("Rapaport API Response:", response);
    if (response.data && response.data.length > 0) {
      const sorted = response.data.sort(function(a, b) {
        return parseFloat(a.Weight_high_size1) - parseFloat(b.Weight_high_size1);
      });
      const record = sorted[0];
      console.log("Best Matched Record:", record);
      const price = record.Rapaport_Price || "";
      console.log("Rapaport Price Found:", price);
      document.getElementById("rapport_price").value = price;
    } else {
      console.warn("No matching record found for:", shape, colorLC, clarityLC, weight);
      document.getElementById("rapport_price").value = "";
    }
  })
  .catch(function(error) {
    console.error("Error fetching Rapaport Price:", error);
    document.getElementById("rapport_price").value = "";
  });
}

document.addEventListener("DOMContentLoaded", function() {
  initRapportPriceTriggers();
});

/* ================= SPECIES CHANGE → HTS / CODE ================= */
document.getElementById("species_lookup").addEventListener("change", function () {
  const recordId = this.value;
  if (!recordId) {
    document.getElementById("hts_field").value  = "";
    document.getElementById("code_field").value = "";
    return;
  }
  ZOHO.CREATOR.DATA.getRecordById({
    app_name: "feiny-app",
    report_name: "All_Stone_Species",
    id: recordId
  })
  .then(function (response) {
    console.log("Full Record:", response);
    if (response.code !== 3000 || !response.data) { console.error("Failed to fetch record"); return; }
    const record = response.data;
    document.getElementById("hts_field").value  = record.HTS                    || "";
    document.getElementById("code_field").value = record.Default_Treatment_Code || "";
  })
  .catch(function (error) { console.error("Error fetching species record:", error); });
});


/* ================= SAVE → ZOHO CREATOR ================= */
function saveRecord() {
  const itemType = document.getElementById("itemType").value;
  const In_SKU   = document.getElementById("In_SKU").value;

  if (!itemType || !In_SKU) {
    alert("Please select Item Type and enter SKU");
    return;
  }

  const saveBtn      = document.getElementById("addRecord");
  const originalText = saveBtn ? saveBtn.textContent : "Save";
  if (saveBtn) {
    saveBtn.textContent = "Saving...";
    saveBtn.disabled    = true;
  }

  function getNumber(id) {
    let val = document.getElementById(id)?.value;
    if (!val) return null;
    val = val.trim().replace(",", ".");
    const num = Number(val);
    return isNaN(num) ? null : num;
  }

  var config = {
    app_name: "feiny-app",
    form_name: "Lot_Master",
    payload: {
      data: {
        "Select":  itemType,
        "In_SKU":  In_SKU,
        "Stock_On_Hand": getNumber("Stock_On_Hand"),
        "Status":  document.getElementById("Status")?.value || "",
        "Treatment": document.getElementById("treatment_lookup")?.value || "",
        "Species":   document.getElementById("species_lookup")?.value   || "",
        "Surface":   document.getElementById("surface_lookup")?.value   || "",
        "Shape":     document.getElementById("shape_lookup")?.value     || "",
        "Origin":           document.getElementById("origin_country")?.value || "",
        "Country_of_Cut":   document.getElementById("country_cut")?.value    || "",
        "HTS":  document.getElementById("hts_field")?.value  || "",
        "Code": document.getElementById("code_field")?.value || "",
        "Rapport_Price": getNumber("Rapport_Price"),
        "Rough_Lot":     document.getElementById("rough_lot")?.value            || "",
        "Name1":         document.getElementById("cs_short_description")?.value || "",
        "Long_Description": document.getElementById("cs_long_description")?.value || "",
        "length_field": getNumber("min_length"),
        "Width":        getNumber("min_width"),
        "Height":       getNumber("min_height"),
        "Length_field1": getNumber("max_length"),
        "Width1":        getNumber("max_width"),
        "Height1":       getNumber("max_height"),
        "weight":        getNumber("weight"),
        "AGL":  document.getElementById("cert_agl")?.checked     || false,
        "GIA":  document.getElementById("cert_gia")?.checked     || false,
        "Gub":  document.getElementById("cert_gubelin")?.checked || false,
        "SSEF": document.getElementById("cert_ssef")?.checked    || false,
        "Other": document.getElementById("cert_other")?.checked  || false,
        "Description2": document.getElementById("certificate_details")?.value || "",
        "Price4":         getNumber("Price4"),
        "Minimum_Price":  getNumber("MinimumPrice"),
        "Unit": document.getElementById("unit_lookup")?.value || "",
        "Partnership_Details": getPartnerRowsData(),
        "Shape3":              document.getElementById("dia_shape")?.value             || "",
        "Color":               document.getElementById("dia_color")?.value             || "",
        "Clarity":             document.getElementById("dia_clarity")?.value           || "",
        "Cut":                 document.getElementById("dia_cut")?.value               || "",
        "Polish":              document.getElementById("dia_polish")?.value            || "",
        "Culet":               document.getElementById("dia_culet")?.value             || "",
        "Symmetry":            document.getElementById("dia_symmetry")?.value          || "",
        "Fluorescence1":       document.getElementById("dia_fluorescence")?.value      || "",
        "Fluorescence_Color":  document.getElementById("dia_colour_fluorescence")?.value || "",
        "Lab":                 document.getElementById("dia_lab")?.value               || "",
        "Length_mm":  getNumber("dia_length"),
        "Width_mm":   getNumber("dia_width"),
        "Depth1":     getNumber("dia_depth"),
        "Table":      getNumber("dia_table"),
        "Depth2":     getNumber("dia_depth_percent"),
        "Weight_Ct":  getNumber("dia_weight"),
        "Price_Per_carat": getNumber("price_per_carat"),
        "Total_Price":     getNumber("total_price"),
        "Rapport_Price1":  getNumber("rapport_price"),
        "Quantity":        getNumber("quantity"),
        "Short_Description1": document.getElementById("diashort_description")?.value || "",
        "Long_Description2":  document.getElementById("dialong_description")?.value  || ""
      }
    }
  };

  console.log("config", config);

  ZOHO.CREATOR.DATA.addRecords(config)
    .then(function(response) {
      console.log("Create response:", response);
      let recordId = null;

      if (response.code === 3000 || response.code === "3000") {
        if (response.data && Array.isArray(response.data) && response.data.length > 0) {
          recordId = response.data[0].ID;
        } else if (response.data && response.data.ID) {
          recordId = response.data.ID;
        } else if (response.details && response.details.id) {
          recordId = response.details.id;
        } else if (response.id) {
          recordId = response.id;
        }

        console.log("Extracted record ID:", recordId);

        if (!recordId) {
          throw new Error("Record created but ID not found in response: " + JSON.stringify(response));
        }

        let uploadPromises = [];

        const certificatePromises = createCertificateRecords(In_SKU);
        if (certificatePromises && certificatePromises.length > 0) {
          uploadPromises = uploadPromises.concat(certificatePromises);
        }

        if (recordId && diaImageFile)   uploadPromises.push(uploadDiaImage(recordId, diaImageFile));
        if (recordId && stoneImageFile) uploadPromises.push(uploadStoneImage(recordId, stoneImageFile));

        return Promise.all(uploadPromises);

      } else {
        throw new Error("Failed to create record: " + (response.message || JSON.stringify(response)));
      }
    })
    .then(function(uploadResults) {
      console.log("Upload results:", uploadResults);
      let message = "Record created successfully!";
      const certificateResults = uploadResults?.filter(u => u.type === "certificate");
      const successCount = certificateResults?.filter(r => r.success).length || 0;
      if (successCount > 0) message += ` ${successCount} certificate(s) created.`;
      alert(message);
      certificateFiles.clear();
      certificateFilesToUpload = [];
      ZOHO.CREATOR.UTIL.navigateTo({ url: "#Report:All_Color_Stone", target: "same" });
    })
    .catch(function(error) {
      console.error("Error:", error);
      alert("Error: " + error.message);
    })
    .finally(function() {
      if (saveBtn) {
        saveBtn.textContent = originalText;
        saveBtn.disabled    = false;
      }
    });
}

/* ================= GET PARTNERSHIP SUBFORM DATA ================= */
function getPartnerRowsData() {
  let partnerRows = [];
  document.querySelectorAll("#partnerBody .partner-row").forEach(function(row){
    partnerRows.push({
      "Partnership_shares": row.querySelector(".partner-share")?.value        || "",
      "Partnership":        row.querySelector(".partner-percent")?.value      || "",
      "Commission":         row.querySelector(".commission-percent")?.value   || "",
      "Commission_Itemized_on_Invoice": row.querySelector(".commission-itemized")?.checked || false
    });
  });
  return partnerRows;
}

/* ================= CREATE CERTIFICATE RECORDS ================= */
function createCertificateRecords(skuValue) {
  const promises = [];
  const rows     = document.querySelectorAll("#certificateBody tr");

  const categoryValue = document.getElementById("itemType")?.value || "";
  const speciesId     = document.getElementById("species_lookup")?.value || "";
  const speciesValue  = speciesMap[speciesId]?.Species || "";

  console.log("Category:", categoryValue);
  console.log("Species:",  speciesValue);

  if (rows.length === 0) { console.log("No certificate rows found"); return promises; }

  console.log("Processing", rows.length, "certificate rows with SKU:", skuValue);

  rows.forEach(function(row, index) {
    const idInput      = row.querySelector(".cert-id");
    const fileInput    = row.querySelector(".cert-file");
    const dateInput    = row.querySelector(".cert-date");
    const notesInput   = row.querySelector(".cert-notes");
    const labSelect    = row.querySelector(".cert-lab");
    const labDescSelect = row.querySelector(".cert-lab-desc");
    const labSupSelect  = row.querySelector(".cert-lab-sup");

    const idValue    = idInput?.value    || "";
    const fileExists = fileInput?.files && fileInput.files.length > 0;

    let dateValue = "";
    if (dateInput && dateInput.value) {
      const dateObj    = new Date(dateInput.value);
      const day        = String(dateObj.getDate()).padStart(2, '0');
      const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
      const month      = monthNames[dateObj.getMonth()];
      const year       = dateObj.getFullYear();
      dateValue = `${day}-${month}-${year}`;
    }

    const notesValue    = notesInput?.value    || "";
    const labValue      = labSelect?.value     || "";
    const labDescValue  = labDescSelect?.value || "";
    const labSupValue   = labSupSelect?.value  || "";

    const hasData = idValue || fileExists || dateValue || notesValue || labValue || labDescValue || labSupValue;
    if (!hasData) { console.log("Row", index, "has no data, skipping"); return; }

    const certData = {
      "ID1":                   idValue,
      "Date_field":            dateValue,
      "Notes":                 notesValue,
      "Lab":                   labValue,
      "Lab_Descriptor":        labDescValue,
      "Laboratory_Supplement": labSupValue,
      "SKU":                   skuValue,
      "Categories":            categoryValue,
      "Species":               speciesValue
    };

    console.log("Creating certificate record", index, "with SKU:", skuValue, "Data:", certData);

    const promise = new Promise((resolve) => {
      ZOHO.CREATOR.DATA.addRecords({
        app_name:  "feiny-app",
        form_name: "Certificate_Uploads",
        payload:   { data: certData }
      })
      .then(function(response) {
        console.log("Certificate record", index, "created:", response);
        let certRecordId = null;
        if (response.code === 3000 || response.code === "3000") {
          if (response.data && Array.isArray(response.data) && response.data.length > 0) {
            certRecordId = response.data[0].ID;
          } else if (response.data && response.data.ID) {
            certRecordId = response.data.ID;
          } else if (response.details && response.details.id) {
            certRecordId = response.details.id;
          } else if (response.id) {
            certRecordId = response.id;
          }
        }
        console.log("Certificate record", index, "ID:", certRecordId);
        if (certRecordId && fileExists) {
          return uploadCertificateFile(certRecordId, fileInput.files[0])
            .then(() => resolve({ type: "certificate", success: true,  index, sku: skuValue, recordId: certRecordId }))
            .catch(err => resolve({ type: "certificate", success: true, fileUploadFailed: true, index, sku: skuValue, recordId: certRecordId, error: err.message }));
        } else {
          resolve({ type: "certificate", success: true, index, sku: skuValue, recordId: certRecordId, noFile: true });
        }
      })
      .catch(function(error) {
        console.error("Certificate record creation failed for row", index, ":", error);
        resolve({ type: "certificate", success: false, error: error.message, index, sku: skuValue });
      });
    });

    promises.push(promise);
  });

  return promises;
}

/* ================= DIAMOND IMAGE UPLOAD ================= */
function uploadDiaImage(recordId, file) {
  return new Promise(function (resolve, reject) {
    ZOHO.CREATOR.FILE.uploadFile({
      app_name:   "feiny-app",
      report_name: "All_Lot_Master",
      id:          recordId,
      field_name:  "item_Image",
      file:        file
    })
    .then(function (response) {
      console.log("Upload response:", response);
      if (response.code === 3000 || response.code === "3000") {
        alert("Image uploaded successfully ✅");
        setImagePreview(file);
        ZOHO.CREATOR.DATA.invokeCustomApi({
          api_name:      "imageupload",
          workspace_name: "ankit_feiny",
          http_method:   "POST",
          content_type:  "application/json",
          payload:       { IDd: recordId, fileFormat: file.name },
          public_key:    "2hXJDxEmMyekhJ7yFtrJV5n14"
        })
        .then(function (r)  { console.log("Custom API SUCCESS:", r); })
        .catch(function (e) { console.error("Custom API ERROR:", e); });
        resolve({ type: "image", success: true });
      } else {
        reject(new Error(response.message || "Upload failed"));
      }
    })
    .catch(function (error) { reject(error); });
  });
}

function setImagePreview(file) {
  diaImageFile = file;
  const preview = document.getElementById("imagePreview");
  if (preview && file) {
    preview.src = URL.createObjectURL(file);
    preview.style.display = "block";
  }
}

function loadExistingImagePreview(recordId) {
  ZOHO.CREATOR.API.getRecordById({ appName: "feiny-app", reportName: "All_Lot_Master", id: recordId })
  .then(function (response) {
    if (response.code === 3000) {
      const imageUrl = response.data.item_Image;
      if (imageUrl) {
        const preview = document.getElementById("imagePreview");
        if (preview) { preview.src = imageUrl; preview.style.display = "block"; }
      }
    }
  })
  .catch(function (err) { console.error("Failed to load existing image:", err); });
}

const preview = document.getElementById("imagePreview");
if (preview) {
  preview.style.cursor = "pointer";
  preview.onclick = function () { if (preview.src) window.open(preview.src, "_blank"); };
}

/* ================= STONE IMAGE UPLOAD ================= */
function uploadStoneImage(recordId, file) {
  return new Promise(function (resolve, reject) {
    ZOHO.CREATOR.FILE.uploadFile({
      app_name:    "feiny-app",
      report_name: "All_Lot_Master",
      id:          recordId,
      field_name:  "item_Image",
      file:        file
    })
    .then(function (response) {
      console.log("Stone image upload response:", response);
      if (response.code === 3000 || response.code === "3000") {
        console.log("Stone image uploaded successfully ✅");
        return ZOHO.CREATOR.DATA.invokeCustomApi({
          api_name:       "imageupload",
          workspace_name: "ankit_feiny",
          http_method:    "POST",
          content_type:   "application/json",
          payload:        { IDd: recordId, fileFormat: file.name },
          public_key:     "2hXJDxEmMyekhJ7yFtrJV5n14"
        });
      } else {
        throw new Error(response.message || "Stone image upload failed");
      }
    })
    .then(function (customResponse) {
      console.log("Custom API SUCCESS:", customResponse);
      resolve({ type: "stoneImage", success: true });
    })
    .catch(function (error) {
      console.error("Error in upload/custom API:", error);
      reject(error);
    });
  });
}

/* ================= UPLOAD CERTIFICATE FILE ================= */
function uploadCertificateFile(recordId, file) {
  return new Promise(function(resolve, reject) {
    ZOHO.CREATOR.FILE.uploadFile({
      app_name:    "feiny-app",
      report_name: "All_Certificate_Details",
      id:          recordId,
      field_name:  "Certificate_Single",
      file:        file
    })
    .then(function(response){
      console.log("Certificate file upload response:", response);
      if (response.code === 3000 || response.code === "3000") {
        resolve("FILEresponse", response);
        ZOHO.CREATOR.DATA.invokeCustomApi({
          api_name:       "asfd",
          workspace_name: "ankit_feiny",
          http_method:    "POST",
          content_type:   "application/json",
          payload:        { IDd: recordId, fileFormat: response.data.filename },
          public_key:     "yUeF2jG7QJWCHXUaEuCQ91XvA"
        })
        .then(function (r)  { console.log(" Custom SUCCESS:", r); })
        .catch(function (e) { console.error("Custom ERROR:", e); });
      } else {
        reject(new Error(response.message || "File upload failed"));
      }
    })
    .catch(function(error){ reject(error); });
  });
}

/* ================= LOAD EXISTING RECORD (EDIT MODE) ================= */
lot_edit = false;

ZOHO.CREATOR.UTIL.getQueryParams().then(function(params) {
  console.log("All Params:", params);
  let recId = params.recId;
  console.log("recId:", recId);
  if (recId) {
    lot_edit = true;
    loadExistingRecord(recId);
  } else {
    console.error("❌ recId not received!");
  }
});

function loadExistingRecord(recordID) {
  ZOHO.CREATOR.DATA.getRecordById({
    report_name: "All_Color_Stone",
    id: recordID
  }).then(function(res) {
    const data = res.data;
    console.log("===== MAIN RECORD DATA =====");
    console.log("data:", data);
    // console.log("data:", JSON.stringify(data, null, 2));


    document.getElementById("In_SKU").value               = data.In_SKU           || "";
    document.getElementById("itemType").value             = data.Select            || "";
    document.getElementById("surface_lookup").value       = (data.Surface && data.Surface.ID)     ? data.Surface.ID     : "";
    document.getElementById("species_lookup").value       = (data.Species && data.Species.ID)     ? data.Species.ID     : "";
    document.getElementById("treatment_lookup").value     = (data.Treatment && data.Treatment.ID) ? data.Treatment.ID   : "";
    document.getElementById("shape_lookup").value         = (data.Shape && data.Shape.ID)         ? data.Shape.ID       : "";
    document.getElementById("origin_country").value       = data.Origin            || "";
    document.getElementById("country_cut").value          = data.Country_of_Cut    || "";
    document.getElementById("hts_field").value            = data.HTS               || "";
    document.getElementById("code_field").value           = data.Code              || "";
    document.getElementById("cs_short_description").value = data.Name1             || "";
    document.getElementById("cs_long_description").value  = data.Long_Description  || "";
    document.getElementById("min_length").value           = data.length_field      || "";
    document.getElementById("min_width").value            = data.Width             || "";
    document.getElementById("min_height").value           = data.Height            || "";
    document.getElementById("max_length").value           = data.Length_field1     || "";
    document.getElementById("max_width").value            = data.Width1            || "";
    document.getElementById("max_height").value           = data.Height1           || "";
    document.getElementById("weight").value               = data.weight            || "";
    document.getElementById("cert_other").checked         = data.Other             || false;
    document.getElementById("cert_gubelin").checked       = data.Gub               || false;
    document.getElementById("cert_agl").checked           = data.AGL               || false;
    document.getElementById("cert_gia").checked           = data.GIA               || false;
    document.getElementById("cert_ssef").checked          = data.SSEF              || false;
    document.getElementById("certificate_details").value  = data.Description2      || "";
    document.getElementById("Price4").value               = data.Price4            || "";
    document.getElementById("MinimumPrice").value         = data.Minimum_Price     || "";
    document.getElementById("unit_lookup").value          = (data.Unit && data.Unit.ID) ? data.Unit.ID : "";

    // ================= CERTIFICATE UPLOADS SUBFORM =================
    

    console.log("===== Fetcthing Certificate Subform DATA =====");
    var config = {
    app_name: "feiny-app",
    report_name: "All_Certificate_Details",
     criteria: 'Lot_Master_ID == ' + recordID + '',
  };
    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  // console.log(response)
  // console.log("data:", response);
  // console.log(JSON.stringify(response, null, 2));

  
    var certData = response.data;

    var certTbody = document.getElementById("certificateBody");
    certTbody.innerHTML = "";
    document.getElementById("certificateuploadsec").style.display = "block";

    if (certData && certData.length > 0) {
      // console.log("Processing certificate item:", certData);
        

      certData.reverse().forEach(function(item) {

        var certCell = item.Certificate_Single
          ? '<a href="' + item.Certificate_Single + '" target="_blank">View File</a>'
          : '<span>No File</span>';

        var tr = document.createElement("tr");
        tr.classList.add("cert-row");
        tr.innerHTML =
          '<td><button type="button" class="remove-btn" onclick="removeRow(this)">❌</button></td>' +
          '<td><input class="cert-id" value="' + (item.ID1 || '') + '"></td>' +
          '<td>' + certCell + '</td>' +
          '<td><input type="date" class="cert-date" value="' + (item.Date_field || '') + '"></td>' +
          '<td><textarea class="cert-notes">' + (item.Notes || '') + '</textarea></td>' +
          '<td><select class="cert-lab"></select></td>' +
          '<td><select class="cert-lab-desc"></select></td>' +
          '<td><select class="cert-lab-sup"></select></td>';

        certTbody.appendChild(tr);

        populateRowSelects(tr);

        setTimeout(function() {
          tr.querySelector(".cert-lab").value      = (item.Lab && item.Lab.ID) ? item.Lab.ID : "";
          tr.querySelector(".cert-lab-desc").value = (item.Lab_Descriptor && item.Lab_Descriptor.ID) ? item.Lab_Descriptor.ID : "";
          tr.querySelector(".cert-lab-sup").value  = (item.Laboratory_Supplement && item.Laboratory_Supplement.ID) ? item.Laboratory_Supplement.ID : "";
        }, 300);

      }); // ← closes certData forEach

    } else {
      console.log("⚠️ No certificate data found");
      addCertificateRow();
    } // ← closes cert if/else



});

        


    // ================= PARTNERSHIP DETAILS SUBFORM =================
var partnerData = data.Partnership_Details;
console.log("PARTNER SUBFORM DATA:", partnerData);

var partnerTbody = document.getElementById("partnerBody");
partnerTbody.innerHTML = "";
document.getElementById("partnershipsec").style.display = "block";

if (partnerData && partnerData.length > 0) {

  partnerData.forEach(function(item) {
    console.log("Processing partner item:", item);

    var tr = document.createElement("tr");
    tr.classList.add("partner-row");

    tr.innerHTML =
      '<td>' +
        '<select class="partner_data_lookup">' +
          '<option value="">Select Partner</option>' +
        '</select>' +
      '</td>' +
      '<td><input type="text" class="partner-share" value="' + (item.Partnership_shares || '') + '"></td>' +
      '<td><input type="text" class="partner-percent" value="' + (item.Partnership || '') + '"></td>' +
      '<td><input type="text" class="commission-percent" value="' + (item.Commission || '') + '"></td>' +
      '<td style="text-align:center;">' +
        '<input type="checkbox" class="commission-itemized" ' + (item.Commission_Itemized_on_Invoice ? 'checked' : '') + '>' +
      '</td>' +
      '<td><textarea class="partner-desc">' + (item.Description) + '</textarea></td>';

    partnerTbody.appendChild(tr);

    // ✅ FIX: Load dropdown then set value
    populatePartnerSelect(tr).then(function() {
      const selectEl = tr.querySelector(".partner_data_lookup");

      if (item.Partner_Name && item.Partner_Name.ID) {
        selectEl.value = item.Partner_Name.ID;
      }
    });

  });

} else {
  console.log("⚠️ No partnership data found");
  addPartnerRow();
} // ← closes partner if/else

  }); // ← closes .then()

} // ← closes loadExistingRecord()