/* ================= JEWELLERY TYPE LOOKUP ================= */
function loadJewelleryTypeLookup() {
  // console.log("Loading jewellery type lookup...");

  ZOHO.CREATOR.DATA.getRecords({
    app_name: "feiny-app",
    report_name: "Jewellery_Type",
  })
    .then(function (response) {
      const styleTypeSelect = document.getElementById("jewellery_type");
      if (!styleTypeSelect) return;
      styleTypeSelect.innerHTML = `<option value="">Select Jewellery Type</option>`;
      if (!response.data || response.data.length === 0) return;
      response.data.forEach(function (record) {
        const option = document.createElement("option");
        option.value = record.ID;
        option.text = record.Description1;
        styleTypeSelect.appendChild(option);
      });
    })
    .catch(function (error) {
      console.error("Style type lookup error:", error);
    });
}
